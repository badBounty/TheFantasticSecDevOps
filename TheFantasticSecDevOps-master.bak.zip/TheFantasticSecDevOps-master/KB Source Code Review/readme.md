# KB Source Code Review

## Contenido
Esta sección contiene la KB con vulns las cuales se añaden como observaciones en Django (puerto bindeado del contenedor Orchestrator). Estas observaciones sirven para determinar por medio de comparación 
que vulns catalogan para ser un issue o no pasan el "whitelisting" (que consiste en esa misma comparación) y si no catalogan son enviadas a través de Slack.
