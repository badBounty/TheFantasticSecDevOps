//TODO 
//When navbar option is selected --> change active panel.

$('.nav-item a').addClass("active");