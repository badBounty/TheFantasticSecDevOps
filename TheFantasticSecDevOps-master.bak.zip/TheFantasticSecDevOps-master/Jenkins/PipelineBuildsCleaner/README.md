### Descripción
En esta sección se encontrarán scripts que deben ser ejecutados en el servidor de Jenkins. Estos pueden ayudar al rendimiento o realizar configuraciones sobre Jenkins de manera automatizada sin realizarlo a través de la app.
### Contenido

| Script             | Descripción                                                                                            |
|--------------------|--------------------------------------------------------------------------------------------------------|
| BuildsCleaner.py   | Script que permite la limpieza de builds de proyectos de manera automatizada excluyendo el último build|
