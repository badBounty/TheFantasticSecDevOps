# Diagramas

## Contenido
En esta sección se encuentran los diagramas principales de SecDevOps. Consisten en un diagrama de arquitectura general, y un diagrama de actividad para cada Pipeline y su tecnología. También, posee un .txt que contiene notas sobre el proceso SecDevOps para ayudar a comprender mejor el proceso y poder solucionar inconvenientes que puedan ir surgiendo.
Además, esta sección contiene un PowerPoint que representa el proceso hecho al cliente.
